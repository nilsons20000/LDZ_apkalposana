#ifndef STRUKTURAS_H_INCLUDED
#define STRUKTURAS_H_INCLUDED
#include <string>
#include <iostream>
using namespace std;
struct Users{
string login ,parole, personalID;
};

#endif // STRUKTURAS_H_INCLUDED
