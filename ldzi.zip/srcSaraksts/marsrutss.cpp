#include "marsrutss.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
marsrutss::marsrutss()
{
    //ctor
}

marsrutss::~marsrutss()
{
    //dtor
}

marsrutss::marsrutss(string marsruts,  string nosaukums){
    this->setMarsruts(marsruts, nosaukums);
}
void marsrutss::setMarsruts(string marsruts,string nosaukums){
	ofstream file(string(string(nosaukums)).c_str(),ios::app);
	file<<marsruts<<",";
	file.close();
}
