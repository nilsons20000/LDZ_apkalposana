#include "Marsruts.h"
#include "Cena.h"
#include "Laiks.h"
#include "VilcienaNumurs.h"
#include "marsrutss.h"

#include <fstream>
#include <iostream>
#include <string>
using namespace std;
Marsruts::Marsruts()
{
    //ctor
}

Marsruts::~Marsruts()
{
    //dtor
}
void Marsruts::pievienot(string nosaukums)
{
    string vilcienaNumurs;string marsruts;string laiks; string cena;

	cout << "Ievadi vilciena numuru numuru: ";
	cin >> vilcienaNumurs;
	cout << "Ievadi marsrutu: ";
	cin >> marsruts;
	cout << "Ievadi laiku: ";
	cin >> laiks;
	cout << "Ievadi cenu: ";
	cin >> cena;
    VilcienaNumurs newVilcienaNumurs(vilcienaNumurs,nosaukums);
    marsrutss newmarsrutss(marsruts,nosaukums);
	Laiks newLaiks(laiks,nosaukums);
	Cena newCena(cena,nosaukums);
}
