#include "VilcienaNumurs.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
VilcienaNumurs::VilcienaNumurs()
{
    //ctor
}

VilcienaNumurs::~VilcienaNumurs()
{
    //dtor
}
VilcienaNumurs::VilcienaNumurs(string VilcienaNumurs,string nosaukums){
    this->setVilcienaNumurs(VilcienaNumurs, nosaukums);
}

void VilcienaNumurs::setVilcienaNumurs(string vilcienaNumurs,string nosaukums){
	ofstream file(string(string(nosaukums)).c_str(),ios::app);
	file<<vilcienaNumurs<<",";
	file.close();
}

