#include "Cena.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
Cena::Cena()
{
    //ctor
}

Cena::~Cena()
{
    //dtor
}

Cena::Cena(string cena,  string nosaukums){
    this->setCena(cena, nosaukums);
}
void Cena::setCena(string cena,string nosaukums){
	ofstream file(string(string(nosaukums)).c_str(),ios::app);
	file<<cena<<","<<endl;
	file.close();
}
