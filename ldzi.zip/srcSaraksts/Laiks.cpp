#include "Laiks.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
Laiks::Laiks()
{
    //ctor
}

Laiks::~Laiks()
{
    //dtor
}

Laiks::Laiks(string laiks,  string nosaukums){
    this->setLaiks(laiks, nosaukums);
}

void Laiks::setLaiks(string laiks,string nosaukums){
	ofstream file(string(string(nosaukums)).c_str(),ios::app);
	file<<"Laiks="<<laiks<<",";
	file.close();
}
